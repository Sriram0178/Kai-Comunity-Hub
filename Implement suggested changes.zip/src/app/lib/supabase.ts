// Mock implementation - no actual Supabase connection required
export * from './mockData';
