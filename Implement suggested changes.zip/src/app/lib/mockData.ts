// Mock data storage using localStorage for persistence

export interface User {
  id: string;
  email: string;
  role: 'student' | 'club_lead';
  name: string;
  interests?: string[];
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  venue: string;
  category: string;
  link?: string;
  created_by: string;
  created_at: string;
  attendee_count: number;
  creator_name?: string;
}

export interface Club {
  id: string;
  name: string;
  description: string;
  category: string;
  join_link?: string;
  created_by: string;
  created_at: string;
  member_count: number;
}

export interface RSVP {
  id: string;
  event_id: string;
  user_id: string;
  created_at: string;
}

export interface ClubMembership {
  id: string;
  club_id: string;
  user_id: string;
  created_at: string;
}

// Initialize with sample data
const initializeData = () => {
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('events')) {
    const sampleEvents: Event[] = [
      {
        id: '1',
        title: 'Tech Talk: AI in Education',
        description: 'Join us for an insightful discussion on how AI is transforming education. Industry experts will share their perspectives.',
        date: '2026-03-15',
        time: '14:00',
        venue: 'Main Auditorium',
        category: 'Technical',
        link: 'https://chat.whatsapp.com/example',
        created_by: 'demo',
        created_at: new Date().toISOString(),
        attendee_count: 45,
        creator_name: 'Demo User',
      },
      {
        id: '2',
        title: 'Basketball Tournament Finals',
        description: 'Cheer for your team in the inter-college basketball championship finals!',
        date: '2026-03-20',
        time: '16:00',
        venue: 'Sports Complex',
        category: 'Sports',
        created_by: 'demo',
        created_at: new Date().toISOString(),
        attendee_count: 120,
        creator_name: 'Sports Club',
      },
      {
        id: '3',
        title: 'Annual Cultural Night',
        description: 'Experience diverse performances including dance, music, and drama from students across campus.',
        date: '2026-03-25',
        time: '18:00',
        venue: 'Open Air Theatre',
        category: 'Cultural',
        created_by: 'demo',
        created_at: new Date().toISOString(),
        attendee_count: 200,
        creator_name: 'Cultural Committee',
      },
    ];
    localStorage.setItem('events', JSON.stringify(sampleEvents));
  }
  
  if (!localStorage.getItem('clubs')) {
    const sampleClubs: Club[] = [
      {
        id: '1',
        name: 'Coding Club',
        description: 'Learn programming, build projects, and participate in hackathons together!',
        category: 'Technical',
        join_link: 'https://chat.whatsapp.com/coding-club',
        created_by: 'demo',
        created_at: new Date().toISOString(),
        member_count: 85,
      },
      {
        id: '2',
        name: 'Photography Club',
        description: 'Capture moments, learn techniques, and explore the art of photography.',
        category: 'Arts',
        join_link: 'https://t.me/photo-club',
        created_by: 'demo',
        created_at: new Date().toISOString(),
        member_count: 52,
      },
      {
        id: '3',
        name: 'Debate Society',
        description: 'Sharpen your critical thinking and public speaking skills through engaging debates.',
        category: 'Academic',
        join_link: 'https://discord.gg/debate',
        created_by: 'demo',
        created_at: new Date().toISOString(),
        member_count: 38,
      },
    ];
    localStorage.setItem('clubs', JSON.stringify(sampleClubs));
  }
  
  if (!localStorage.getItem('rsvps')) {
    localStorage.setItem('rsvps', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('club_memberships')) {
    localStorage.setItem('club_memberships', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('currentUser')) {
    localStorage.setItem('currentUser', '');
  }
};

initializeData();

// Mock auth functions
export const mockAuth = {
  signUp: async (email: string, password: string, name: string, role: 'student' | 'club_lead') => {
    const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Check if user exists
    if (users.find(u => u.email === email)) {
      throw new Error('User already exists');
    }
    
    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      role,
      interests: [],
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', newUser.id);
    
    return { user: newUser };
  },
  
  signIn: async (email: string, password: string) => {
    const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email);
    
    if (!user) {
      throw new Error('Invalid credentials');
    }
    
    localStorage.setItem('currentUser', user.id);
    return { user };
  },
  
  signOut: async () => {
    localStorage.setItem('currentUser', '');
  },
  
  getUser: async () => {
    const userId = localStorage.getItem('currentUser');
    if (!userId) return { user: null };
    
    const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.id === userId);
    
    return { user: user || null };
  },
};

// Mock database functions
export const mockDb = {
  events: {
    getAll: async () => {
      const events: Event[] = JSON.parse(localStorage.getItem('events') || '[]');
      return events;
    },
    
    create: async (event: Omit<Event, 'id' | 'created_at' | 'attendee_count'>) => {
      const events: Event[] = JSON.parse(localStorage.getItem('events') || '[]');
      const newEvent: Event = {
        ...event,
        id: Date.now().toString(),
        created_at: new Date().toISOString(),
        attendee_count: 0,
      };
      events.push(newEvent);
      localStorage.setItem('events', JSON.stringify(events));
      return newEvent;
    },
    
    update: async (id: string, updates: Partial<Event>) => {
      const events: Event[] = JSON.parse(localStorage.getItem('events') || '[]');
      const index = events.findIndex(e => e.id === id);
      if (index !== -1) {
        events[index] = { ...events[index], ...updates };
        localStorage.setItem('events', JSON.stringify(events));
      }
    },
    
    getByUser: async (userId: string) => {
      const events: Event[] = JSON.parse(localStorage.getItem('events') || '[]');
      return events.filter(e => e.created_by === userId);
    },
  },
  
  clubs: {
    getAll: async () => {
      const clubs: Club[] = JSON.parse(localStorage.getItem('clubs') || '[]');
      return clubs;
    },
    
    create: async (club: Omit<Club, 'id' | 'created_at' | 'member_count'>) => {
      const clubs: Club[] = JSON.parse(localStorage.getItem('clubs') || '[]');
      const newClub: Club = {
        ...club,
        id: Date.now().toString(),
        created_at: new Date().toISOString(),
        member_count: 0,
      };
      clubs.push(newClub);
      localStorage.setItem('clubs', JSON.stringify(clubs));
      return newClub;
    },
    
    update: async (id: string, updates: Partial<Club>) => {
      const clubs: Club[] = JSON.parse(localStorage.getItem('clubs') || '[]');
      const index = clubs.findIndex(c => c.id === id);
      if (index !== -1) {
        clubs[index] = { ...clubs[index], ...updates };
        localStorage.setItem('clubs', JSON.stringify(clubs));
      }
    },
  },
  
  rsvps: {
    getAll: async () => {
      const rsvps: RSVP[] = JSON.parse(localStorage.getItem('rsvps') || '[]');
      return rsvps;
    },
    
    create: async (eventId: string, userId: string) => {
      const rsvps: RSVP[] = JSON.parse(localStorage.getItem('rsvps') || '[]');
      
      // Check if already exists
      if (rsvps.find(r => r.event_id === eventId && r.user_id === userId)) {
        throw new Error('Already RSVP\'d');
      }
      
      const newRsvp: RSVP = {
        id: Date.now().toString(),
        event_id: eventId,
        user_id: userId,
        created_at: new Date().toISOString(),
      };
      rsvps.push(newRsvp);
      localStorage.setItem('rsvps', JSON.stringify(rsvps));
      return newRsvp;
    },
    
    getByUser: async (userId: string) => {
      const rsvps: RSVP[] = JSON.parse(localStorage.getItem('rsvps') || '[]');
      return rsvps.filter(r => r.user_id === userId);
    },
  },
  
  clubMemberships: {
    getAll: async () => {
      const memberships: ClubMembership[] = JSON.parse(localStorage.getItem('club_memberships') || '[]');
      return memberships;
    },
    
    create: async (clubId: string, userId: string) => {
      const memberships: ClubMembership[] = JSON.parse(localStorage.getItem('club_memberships') || '[]');
      
      // Check if already exists
      if (memberships.find(m => m.club_id === clubId && m.user_id === userId)) {
        throw new Error('Already a member');
      }
      
      const newMembership: ClubMembership = {
        id: Date.now().toString(),
        club_id: clubId,
        user_id: userId,
        created_at: new Date().toISOString(),
      };
      memberships.push(newMembership);
      localStorage.setItem('club_memberships', JSON.stringify(memberships));
      return newMembership;
    },
    
    getByUser: async (userId: string) => {
      const memberships: ClubMembership[] = JSON.parse(localStorage.getItem('club_memberships') || '[]');
      return memberships.filter(m => m.user_id === userId);
    },
  },
};
