import { useState, useEffect, useRef } from 'react';
import { mockDb } from '../lib/supabase';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Send, Sparkles, Calendar, Users as UsersIcon } from 'lucide-react';
import { Badge } from './ui/badge';

interface ChatTabProps {
  userId: string;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function ChatTab({ userId }: ChatTabProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hey! I'm Kai, your campus community assistant. Ask me anything about events, clubs, or what's happening around campus! 🎉",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    "What's happening this week?",
    "Which club should I join?",
    "Show me tech events",
    "Find sports clubs",
  ];

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const generateKaiResponse = async (userMessage: string): Promise<string> => {
    const lowerMsg = userMessage.toLowerCase();

    // Fetch events for recommendations
    const events = await mockDb.events.getAll();

    // Fetch clubs for recommendations
    const clubs = await mockDb.clubs.getAll();

    // Event-related queries
    if (lowerMsg.includes('event') || lowerMsg.includes('happening') || lowerMsg.includes('this week')) {
      if (!events || events.length === 0) {
        return "Hmm, looks a bit quiet on the events front rn 🤔 Why not create one? Just head to the Events tab and hit that '30-Second Event Creation' button!";
      }

      let response = "Here's what's coming up! 📅\n\n";
      events.slice(0, 3).forEach((event, idx) => {
        response += `${idx + 1}. **${event.title}**\n`;
        response += `   📍 ${event.venue} | 🕐 ${new Date(event.date).toLocaleDateString()} at ${event.time}\n`;
        response += `   ${event.description.substring(0, 80)}...\n\n`;
      });
      response += "Check the Events tab to RSVP! 🎉";
      return response;
    }

    // Club-related queries
    if (lowerMsg.includes('club') || lowerMsg.includes('join') || lowerMsg.includes('community')) {
      if (!clubs || clubs.length === 0) {
        return "No clubs listed yet, but you could start one! 💪 Head to the Clubs tab to create your community.";
      }

      // Check if asking about specific category
      let filteredClubs = clubs;
      if (lowerMsg.includes('tech') || lowerMsg.includes('coding')) {
        filteredClubs = clubs.filter(c => c.category === 'Technical');
      } else if (lowerMsg.includes('sport')) {
        filteredClubs = clubs.filter(c => c.category === 'Sports');
      } else if (lowerMsg.includes('cultural') || lowerMsg.includes('art')) {
        filteredClubs = clubs.filter(c => c.category === 'Cultural' || c.category === 'Arts');
      }

      if (filteredClubs.length === 0) {
        return "Hmm, no clubs in that category yet. But there are other cool communities! Check out the Clubs tab to explore all options. 🌟";
      }

      let response = "Based on your vibe, here are some clubs you might love:\n\n";
      filteredClubs.slice(0, 3).forEach((club, idx) => {
        response += `${idx + 1}. **${club.name}** (${club.category})\n`;
        response += `   ${club.description.substring(0, 80)}...\n`;
        response += `   👥 ${club.member_count} members\n\n`;
      });
      response += "One-tap join from the Clubs tab! ✨";
      return response;
    }

    // Interest-based recommendations
    if (lowerMsg.includes('interest') || lowerMsg.includes('recommend') || lowerMsg.includes('suggest')) {
      return "I'd love to give you personalized recommendations! 🎯\n\nTell me what you're into:\n• Tech & coding?\n• Sports & fitness?\n• Arts & culture?\n• Academic stuff?\n• Just wanna vibe with cool people?\n\nOr check out the Clubs tab where I've already curated some recommendations for you! ✨";
    }

    // Creating events
    if (lowerMsg.includes('create') || lowerMsg.includes('post')) {
      return "Want to create an event? It takes literally 30 seconds! ⚡\n\nJust:\n1. Go to Events tab\n2. Click 'Create Event (30s)'\n3. Fill in title, date, time, venue, and link\n4. Hit publish!\n\nKai auto-formats and publishes it to the campus hub instantly. No friction, just vibes! 🚀";
    }

    // Growth hook
    if (lowerMsg.includes('vip') || lowerMsg.includes('reward') || lowerMsg.includes('refer')) {
      return "Pro tip! 🌟\n\nEvery event has a 'Bring 3 friends → unlock VIP notes/early entry/exclusive pass' mechanic. It's ethical, transparent, and wildly effective for growth.\n\nInvite your squad, unlock cool perks, and help the campus community grow! 🎉";
    }

    // Default helpful response
    return `Great question! I'm here to help you:\n\n✨ Discover events happening on campus\n🎯 Find clubs matching your interests\n📅 Get personalized recommendations\n⚡ Quick-create events in 30 seconds\n\nTry asking me:\n• "What's happening this week?"\n• "Which club should I join?"\n• "Show me tech events"\n\nWhat would you like to know? 😊`;
  };

  const handleSendMessage = async (messageText?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Generate Kai's response
    setTimeout(async () => {
      const kaiResponse = await generateKaiResponse(textToSend);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: kaiResponse,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg p-4">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="size-6 text-purple-600" />
          <h2 className="text-xl font-bold">Ask Kai Anything</h2>
        </div>
        <p className="text-gray-700">
          "What's happening this week?" or "Which club should I join based on my interests?" — Kai answers in natural language, no search needed. 🎯
        </p>
      </div>

      {/* Quick Questions */}
      <div className="flex flex-wrap gap-2">
        {quickQuestions.map((question) => (
          <Badge
            key={question}
            variant="outline"
            className="cursor-pointer hover:bg-purple-100 border-purple-300 text-purple-700 px-3 py-1.5"
            onClick={() => handleSendMessage(question)}
          >
            {question}
          </Badge>
        ))}
      </div>

      {/* Chat Messages */}
      <Card className="h-[500px] flex flex-col">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${
                message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <Avatar className={message.role === 'assistant' ? 'bg-gradient-to-br from-purple-600 to-blue-500' : 'bg-gray-300'}>
                <AvatarFallback className="text-white">
                  {message.role === 'assistant' ? '🤖' : '👤'}
                </AvatarFallback>
              </Avatar>
              
              <div
                className={`flex-1 max-w-[80%] rounded-lg p-4 ${
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-purple-600 to-blue-500 text-white ml-auto'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                <div className="whitespace-pre-wrap break-words">{message.content}</div>
                <div className={`text-xs mt-2 ${message.role === 'user' ? 'text-purple-100' : 'text-gray-500'}`}>
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <Avatar className="bg-gradient-to-br from-purple-600 to-blue-500">
                <AvatarFallback className="text-white">🤖</AvatarFallback>
              </Avatar>
              <div className="bg-gray-100 rounded-lg p-4">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex gap-2"
          >
            <Input
              placeholder="Ask Kai anything..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1"
            />
            <Button
              type="submit"
              className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white"
            >
              <Send className="size-4" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  );
}