import { useState, useEffect } from 'react';
import { mockDb, Event } from '../lib/supabase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar, Clock, MapPin, Users } from 'lucide-react';

interface MyEventsTabProps {
  userId: string;
}

export default function MyEventsTab({ userId }: MyEventsTabProps) {
  const [createdEvents, setCreatedEvents] = useState<Event[]>([]);
  const [attendingEvents, setAttendingEvents] = useState<Event[]>([]);
  const [allMyEvents, setAllMyEvents] = useState<Event[]>([]);

  useEffect(() => {
    fetchMyEvents();
  }, [userId]);

  const fetchMyEvents = async () => {
    // Fetch events created by user
    const created = await mockDb.events.getByUser(userId);
    setCreatedEvents(created || []);

    // Fetch events user is attending
    const rsvps = await mockDb.rsvps.getByUser(userId);

    if (rsvps && rsvps.length > 0) {
      const eventIds = rsvps.map(r => r.event_id);
      const allEvents = await mockDb.events.getAll();
      const attending = allEvents.filter(e => eventIds.includes(e.id));
      setAttendingEvents(attending || []);
    }

    // Combine all events
    const allEvents = [...(created || []), ...(attendingEvents || [])];
    const uniqueEvents = Array.from(new Map(allEvents.map(e => [e.id, e])).values());
    setAllMyEvents(uniqueEvents);
  };

  const renderEventCard = (event: Event) => (
    <Card key={event.id} className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <Badge className="bg-gradient-to-r from-purple-600 to-blue-500 text-white">
            {event.category}
          </Badge>
        </div>
        <CardTitle className="mt-2">{event.title}</CardTitle>
        <CardDescription className="line-clamp-2">{event.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Calendar className="size-4" />
          <span>{new Date(event.date).toLocaleDateString()}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Clock className="size-4" />
          <span>{event.time}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <MapPin className="size-4" />
          <span>{event.venue}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Users className="size-4" />
          <span>{event.attendee_count} attending</span>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">My Events</h2>
        <p className="text-gray-600">Track your created events and RSVPs</p>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="grid w-full grid-cols-3 bg-white shadow-sm">
          <TabsTrigger value="all" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
            All ({allMyEvents.length})
          </TabsTrigger>
          <TabsTrigger value="created" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
            Created ({createdEvents.length})
          </TabsTrigger>
          <TabsTrigger value="attending" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
            Attending ({attendingEvents.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          {allMyEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allMyEvents.map(renderEventCard)}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No events yet</p>
              <p className="text-gray-400 mt-2">Create or RSVP to events to see them here!</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="created" className="mt-6">
          {createdEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {createdEvents.map(renderEventCard)}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">You haven't created any events yet</p>
              <p className="text-gray-400 mt-2">Use the 30-second event creation in the Events tab!</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="attending" className="mt-6">
          {attendingEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {attendingEvents.map(renderEventCard)}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">You haven't RSVP'd to any events</p>
              <p className="text-gray-400 mt-2">Check out the Events tab to find something interesting!</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}