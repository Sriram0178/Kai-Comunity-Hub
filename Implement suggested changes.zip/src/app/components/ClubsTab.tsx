import { useState, useEffect } from 'react';
import { mockDb, Club } from '../lib/supabase';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Users, Plus, Link as LinkIcon, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

interface ClubsTabProps {
  userId: string;
}

export default function ClubsTab({ userId }: ClubsTabProps) {
  const [clubs, setClubs] = useState<Club[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [joinLink, setJoinLink] = useState('');

  const categories = ['Academic', 'Sports', 'Cultural', 'Technical', 'Social', 'Arts', 'Environment'];

  useEffect(() => {
    fetchClubs();
  }, []);

  const fetchClubs = async () => {
    const data = await mockDb.clubs.getAll();
    setClubs(data || []);
  };

  const handleCreateClub = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await mockDb.clubs.create({
        name,
        description,
        category,
        join_link: joinLink,
        created_by: userId,
      });

      toast.success('🎉 Club created successfully!');
      setIsCreateDialogOpen(false);
      resetForm();
      fetchClubs();
    } catch (error: any) {
      toast.error(error.message || 'Failed to create club');
    } finally {
      setLoading(false);
    }
  };

  const handleJoinClub = async (clubId: string, joinLink?: string) => {
    try {
      // Check if already joined
      const memberships = await mockDb.clubMemberships.getByUser(userId);
      const existing = memberships.find(m => m.club_id === clubId);

      if (existing) {
        toast.info('You\'re already a member of this club!');
        if (joinLink) window.open(joinLink, '_blank');
        return;
      }

      // Create membership
      await mockDb.clubMemberships.create(clubId, userId);

      // Update member count
      const club = clubs.find(c => c.id === clubId);
      if (club) {
        await mockDb.clubs.update(clubId, { 
          member_count: club.member_count + 1 
        });
      }

      toast.success('✨ One-tap join successful! Welcome to the community!');
      
      // Open join link if provided
      if (joinLink) {
        setTimeout(() => window.open(joinLink, '_blank'), 500);
      }

      fetchClubs();
    } catch (error: any) {
      toast.error(error.message || 'Failed to join club');
    }
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setCategory('');
    setJoinLink('');
  };

  // Simple recommendation logic - show clubs with similar interests
  const getRecommendedClubs = () => {
    // In a real app, this would use user interests
    return clubs.slice(0, 3).map(c => c.id);
  };

  const recommendedClubIds = getRecommendedClubs();

  return (
    <div className="space-y-6">
      {/* Header with Create Button */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Discover Clubs</h2>
          <p className="text-gray-600">Find your community with AI-powered recommendations</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white">
              <Plus className="size-4 mr-2" />
              Create Club
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create a New Club</DialogTitle>
              <DialogDescription>
                Build your community and connect with like-minded students
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleCreateClub} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Club Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Coding Club"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Tell us about your club..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select value={category} onValueChange={setCategory} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="joinLink">Join Link (WhatsApp/Telegram/Discord) *</Label>
                <Input
                  id="joinLink"
                  type="url"
                  placeholder="https://..."
                  value={joinLink}
                  onChange={(e) => setJoinLink(e.target.value)}
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white"
                  disabled={loading}
                >
                  {loading ? 'Creating...' : 'Create Club'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Recommended Clubs */}
      {recommendedClubIds.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="size-5 text-purple-600" />
            <h3 className="text-lg font-semibold">Recommended for You</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {clubs
              .filter(club => recommendedClubIds.includes(club.id))
              .map((club) => (
                <Card key={club.id} className="hover:shadow-lg transition-shadow border-2 border-purple-200">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <Badge className="bg-gradient-to-r from-purple-600 to-blue-500 text-white">
                        {club.category}
                      </Badge>
                      <Badge variant="outline" className="border-purple-600 text-purple-600">
                        <Sparkles className="size-3 mr-1" />
                        Recommended
                      </Badge>
                    </div>
                    <CardTitle className="mt-2">{club.name}</CardTitle>
                    <CardDescription className="line-clamp-2">{club.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Users className="size-4" />
                      <span>{club.member_count} members</span>
                    </div>

                    <Button
                      onClick={() => handleJoinClub(club.id, club.join_link)}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white"
                    >
                      <LinkIcon className="size-4 mr-2" />
                      One-Tap Join
                    </Button>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      )}

      {/* All Clubs */}
      <div>
        <h3 className="text-lg font-semibold mb-4">All Clubs</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {clubs
            .filter(club => !recommendedClubIds.includes(club.id))
            .map((club) => (
              <Card key={club.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <Badge className="bg-gradient-to-r from-purple-600 to-blue-500 text-white">
                      {club.category}
                    </Badge>
                  </div>
                  <CardTitle className="mt-2">{club.name}</CardTitle>
                  <CardDescription className="line-clamp-2">{club.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users className="size-4" />
                    <span>{club.member_count} members</span>
                  </div>

                  <Button
                    onClick={() => handleJoinClub(club.id, club.join_link)}
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white"
                  >
                    <LinkIcon className="size-4 mr-2" />
                    One-Tap Join
                  </Button>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>

      {clubs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No clubs yet</p>
          <p className="text-gray-400 mt-2">Be the first to create a club!</p>
        </div>
      )}
    </div>
  );
}