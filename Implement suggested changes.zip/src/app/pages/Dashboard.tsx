import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { mockAuth } from '../lib/supabase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { LogOut, Zap } from 'lucide-react';
import { toast } from 'sonner';
import EventsTab from '../components/EventsTab';
import ClubsTab from '../components/ClubsTab';
import ChatTab from '../components/ChatTab';
import MyEventsTab from '../components/MyEventsTab';

export default function Dashboard() {
  const [userName, setUserName] = useState('');
  const [userId, setUserId] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    const { user } = await mockAuth.getUser();
    
    if (!user) {
      navigate('/login');
      return;
    }

    setUserId(user.id);
    setUserName(user.name || 'Student');
  };

  const handleLogout = async () => {
    await mockAuth.signOut();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-500 text-white p-4 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 backdrop-blur-sm p-2 rounded-full">
              <Zap className="size-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Kai Campus Hub</h1>
              <p className="text-sm text-purple-100">Hey {userName}! 👋</p>
            </div>
          </div>
          <Button
            onClick={handleLogout}
            variant="ghost"
            className="text-white hover:bg-white/20"
          >
            <LogOut className="size-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-4">
        <Tabs defaultValue="events" className="mt-6">
          <TabsList className="grid w-full grid-cols-4 mb-6 bg-white shadow-md">
            <TabsTrigger value="events" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
              Events
            </TabsTrigger>
            <TabsTrigger value="clubs" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
              Clubs
            </TabsTrigger>
            <TabsTrigger value="chat" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
              Chat with Kai
            </TabsTrigger>
            <TabsTrigger value="my-events" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-500 data-[state=active]:text-white">
              My Events
            </TabsTrigger>
          </TabsList>

          <TabsContent value="events">
            <EventsTab userId={userId} />
          </TabsContent>

          <TabsContent value="clubs">
            <ClubsTab userId={userId} />
          </TabsContent>

          <TabsContent value="chat">
            <ChatTab userId={userId} />
          </TabsContent>

          <TabsContent value="my-events">
            <MyEventsTab userId={userId} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}