import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { mockAuth, mockDb } from '../lib/supabase';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { LogOut, Zap, Calendar, Users, TrendingUp, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function AdminDashboard() {
  const [userName, setUserName] = useState('');
  const [stats, setStats] = useState({
    totalEvents: 0,
    totalAttendees: 0,
    totalClubs: 0,
    totalMembers: 0,
  });
  const [categoryData, setCategoryData] = useState<any[]>([]);
  const [recentEvents, setRecentEvents] = useState<any[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    checkUser();
    fetchAnalytics();
  }, []);

  const checkUser = async () => {
    const { user } = await mockAuth.getUser();
    
    if (!user) {
      navigate('/login');
      return;
    }

    setUserName(user.name || 'Admin');
    
    // Redirect if not club lead
    if (user.role !== 'club_lead') {
      navigate('/dashboard');
    }
  };

  const fetchAnalytics = async () => {
    // Fetch total events
    const events = await mockDb.events.getAll();

    const totalEvents = events?.length || 0;
    const totalAttendees = events?.reduce((sum, e) => sum + (e.attendee_count || 0), 0) || 0;

    // Fetch total clubs
    const clubs = await mockDb.clubs.getAll();

    const totalClubs = clubs?.length || 0;
    const totalMembers = clubs?.reduce((sum, c) => sum + (c.member_count || 0), 0) || 0;

    setStats({
      totalEvents,
      totalAttendees,
      totalClubs,
      totalMembers,
    });

    // Category distribution
    if (events) {
      const categoryCount: { [key: string]: number } = {};
      events.forEach(event => {
        categoryCount[event.category] = (categoryCount[event.category] || 0) + 1;
      });

      const categoryChartData = Object.entries(categoryCount).map(([category, count]) => ({
        category,
        count,
      }));

      setCategoryData(categoryChartData);
    }

    // Recent events with performance
    if (events) {
      const sortedEvents = events
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
        .slice(0, 5);
      
      setRecentEvents(sortedEvents);
    }
  };

  const handleLogout = async () => {
    await mockAuth.signOut();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  const COLORS = ['#9333ea', '#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-500 text-white p-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 backdrop-blur-sm p-2 rounded-full">
              <Zap className="size-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Campus Captains Dashboard</h1>
              <p className="text-sm text-purple-100">Welcome back, {userName}! 👋</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => navigate('/dashboard')}
              variant="ghost"
              className="text-white hover:bg-white/20"
            >
              Student View
            </Button>
            <Button
              onClick={handleLogout}
              variant="ghost"
              className="text-white hover:bg-white/20"
            >
              <LogOut className="size-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Header Section */}
        <div>
          <h2 className="text-3xl font-bold mb-2">Analytics Overview</h2>
          <p className="text-gray-600">Real-time insights into campus community engagement</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Events</CardTitle>
              <Calendar className="size-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalEvents}</div>
              <p className="text-xs opacity-80 mt-1">Events posted on campus</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Attendees</CardTitle>
              <Users className="size-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalAttendees}</div>
              <p className="text-xs opacity-80 mt-1">RSVPs received</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-500 to-cyan-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Clubs</CardTitle>
              <BarChart3 className="size-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalClubs}</div>
              <p className="text-xs opacity-80 mt-1">Active communities</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Community Members</CardTitle>
              <TrendingUp className="size-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalMembers}</div>
              <p className="text-xs opacity-80 mt-1">Members joined</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Category Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Event Category Distribution</CardTitle>
              <CardDescription>Events by category</CardDescription>
            </CardHeader>
            <CardContent>
              {categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={categoryData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#9333ea" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-400">
                  No event data yet
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Category Breakdown</CardTitle>
              <CardDescription>Distribution overview</CardDescription>
            </CardHeader>
            <CardContent>
              {categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-400">
                  No event data yet
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Events Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Events Performance</CardTitle>
            <CardDescription>Latest events and their engagement metrics</CardDescription>
          </CardHeader>
          <CardContent>
            {recentEvents.length > 0 ? (
              <div className="space-y-4">
                {recentEvents.map((event) => (
                  <div key={event.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex-1">
                      <h4 className="font-semibold">{event.title}</h4>
                      <p className="text-sm text-gray-600">{event.category} • {new Date(event.date).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2 text-purple-600 font-semibold">
                        <Users className="size-4" />
                        <span>{event.attendee_count} RSVPs</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                No events to display
              </div>
            )}
          </CardContent>
        </Card>

        {/* Growth Hook Info */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="size-5 text-purple-600" />
              Growth Hook Active
            </CardTitle>
            <CardDescription>
              Viral growth mechanism in action
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">
              Every event includes a <strong>"Bring 3 friends → unlock VIP notes/early entry/exclusive pass"</strong> mechanic. 
              This ethical, transparent, and wildly effective referral system drives organic community growth. 
              Data shows significant increases in registrations and engagement! 🚀
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}